package My_Project.dbms;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;
import org.hibernate.Session;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;

public class CustomerInput extends Composite {
	private Text txtName;
	private Text txtEmail;

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public CustomerInput(Composite parent, int style,Session session) {
		super(parent, style);
		final Features sys = new Features(session);
		
		
		txtName = new Text(this, SWT.BORDER);
		txtName.setBounds(124, 106, 213, 29);
		
		txtEmail = new Text(this, SWT.BORDER);
		txtEmail.setBounds(124, 166, 213, 29);
		Button btnNewButton = new Button(this, SWT.NONE);
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				sys.createCustomer(txtName.getText(), txtEmail.getText());
			}
		});

		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
//				System.out.println(txtName.getText());
				
			}
		});
		btnNewButton.setBounds(268, 251, 93, 29);
		btnNewButton.setText("Ok");
		
		Button btnNewButton_1 = new Button(this, SWT.NONE);
		btnNewButton_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
			}
		});
		btnNewButton_1.setBounds(30, 251, 93, 29);
		btnNewButton_1.setText("Cancel");
		
		Label lblNewLabel = new Label(this, SWT.NONE);
		lblNewLabel.setBounds(30, 106, 70, 17);
		lblNewLabel.setText("Name");
		
		Label lblEmail = new Label(this, SWT.NONE);
		lblEmail.setText("Email");
		lblEmail.setBounds(30, 166, 70, 17);
		
		Label lblCustomerInput = new Label(this, SWT.NONE);
		lblCustomerInput.setText("Customer Input");
		lblCustomerInput.setBounds(29, 10, 213, 42);

	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
