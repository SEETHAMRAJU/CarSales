package My_Project.dbms;

import java.util.*; 

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class Features {
	
	private Session session;
	private List<Integer> custom = new ArrayList<Integer>();
	private List<Integer> orders = new ArrayList<Integer>();
	
	public Features(Session session)
	{
		this.session = session;
	}
	
	public Session getSession() {
		return session;
	}
	
	public void setSession(Session session) {
		this.session = session;
	}

	
	public void createCustomer(String name,String email) {
		Customer cus = new Customer(name,email);
		
		Transaction tx = session.beginTransaction();
		String hql = "FROM Customer AS E WHERE E.name = \'"+cus.getName()+"\' AND E.email = \'"+cus.getEmail()+"\'";
		Query query = session.createQuery(hql);
		List<Customer> results = query.list();
		if(results.size()!=0) {
			System.out.println("Duplicate Customer Information");
		}
		else {
			session.save(cus);
			tx.commit();
		}
	}
	
	
	
	public void createDealer(Dealer dealer) {
		Transaction tx = session.beginTransaction();
		session.save(dealer);
		tx.commit();
	}	

	public void placeOrder(int cust_id, int dealer_id) {
		Order ord= new Order(cust_id,dealer_id);
		Transaction tx = session.beginTransaction();
		session.save(ord);
		session.persist(ord);
		tx.commit();
		
		orders.add(ord.getOrder_id());
		System.out.println("YOUR ORDER ID : "+ord.getOrder_id());
		
		
	}
	
	public int getCustomerID(String name, String email)
	{
		Transaction tx = session.beginTransaction();
		String hql = "FROM Customer AS E WHERE E.name = \'"+name+"\' AND E.email = \'"+email+"\'";
		Query query = session.createQuery(hql);
		List<Customer> results = query.list();
		tx.commit();
		return results.get(0).getCustomer_id();
	}
	
	public String getOrderStatus(int order_id) {
		int i=0;
		while(!orders.isEmpty())
		{
			if(orders.get(i)==order_id) {
//				System.out.println("NOT YET MANUFACTURED");
				return "NOT YET MANUFACTURED";
			}
		}
//		System.out.println("PROCESSED");
		return "PROCESSED";		
	}
	

	
	
	public void produceVehicle() {
		int i = 0;
		while(i < orders.size())
		{
			
			System.out.println("PROCESSING ORDER "+orders.get(i));
			int ind = orders.get(i);
			Vehicle veh = new Vehicle(ind,ind,ind,"Hyundai","A","P");
			Transaction tx = session.beginTransaction();
			Order ord = (Order) session.load(Order.class, veh.getOrder_id());
			veh.setOrder(ord);
			ord.setStatus("MANUFACTURED");
			session.save(veh);
			session.persist(veh);
			session.saveOrUpdate(ord);
			System.out.println("VEHICLE ID "+veh.getOrder_id()+" MANUFACTURED");
			tx.commit();
			custom.add(ord.getCustomer_id());
			i++;
		}
		orders.clear();
	}
	
	
	public void deliverCustomer() {
		String hql = "FROM Order AS O WHERE O.status = \'"+"MANUFACTURED"+"\'";
		Query query = session.createQuery(hql);
		List<Order> results = query.list();
		int i=0;
		while(i<results.size()) {
			Order ord = (Order) results.get(i);
			ord.setStatus("DELIVERED");
			Transaction tx = session.beginTransaction();
			session.update(ord);
			tx.commit();
			System.out.println("ORDER "+ord.getOrder_id()+"DELIVERED");
			i++;
		}
	}
	public void contactCustomer() {
		int i =0;
		while(i<custom.size()) {
			Customer cust = session.load(Customer.class, custom.get(i));
			System.out.println("CONTACTED"+ cust.getName()+ " @ " + cust.getEmail());
			i++;
		}
		custom.clear();
	}
	
//	public void getStatus()
	public void exitsystem() {
		session.close();
		System.out.println("THANK YOU!!!");
		
	}
	
	
	
	
	
	
	
	
}
