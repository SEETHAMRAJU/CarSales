package My_Project.dbms;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.StackLayout;
import org.eclipse.wb.swt.SWTResourceManager;
import org.hibernate.Session;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class Menu extends Composite {

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public Menu(Composite parent, int style,StackLayout layout,Session sessi) {
		super(parent, style);
		setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND));
		final StackLayout lay = layout;
		final Session session = sessi;
		final Composite mine = parent;
		
		
		Button btnNewButton = new Button(this, SWT.NONE);
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				lay.topControl = new CustomerInput(mine,SWT.NONE,session);
				mine.layout();
			}
		});
		btnNewButton.setForeground(SWTResourceManager.getColor(SWT.COLOR_LIST_FOREGROUND));
		btnNewButton.setBounds(81, 54, 127, 29);
		btnNewButton.setText("New customer");
		
		Button btnNewButton_1 = new Button(this, SWT.NONE);
		btnNewButton_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				lay.topControl = new DealerInput(mine,SWT.NONE,session);
				mine.layout();
				}
		});
		btnNewButton_1.setForeground(SWTResourceManager.getColor(SWT.COLOR_LIST_FOREGROUND));
		btnNewButton_1.setBounds(81, 236, 127, 29);
		btnNewButton_1.setText("Dealer");
		
		Button btnNewButton_2 = new Button(this, SWT.NONE);
		btnNewButton_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				lay.topControl = new manufacturerprocedure(mine,SWT.NONE,session);
				mine.layout();

			}
		});
		btnNewButton_2.setForeground(SWTResourceManager.getColor(SWT.COLOR_LIST_FOREGROUND));
		btnNewButton_2.setBounds(81, 301, 127, 29);
		btnNewButton_2.setText("Manufacturer");
		
		Button btnNewButton_3 = new Button(this, SWT.NONE);
		btnNewButton_3.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				lay.topControl = new oldcust(mine,SWT.NONE,session);
				mine.layout();
			}
		});
		btnNewButton_3.setForeground(SWTResourceManager.getColor(SWT.COLOR_LIST_FOREGROUND));
		btnNewButton_3.setBounds(81, 117, 127, 29);
		btnNewButton_3.setText("Loyal Customer");

	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

}
