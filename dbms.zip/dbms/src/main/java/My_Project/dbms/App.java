package My_Project.dbms;

//import java.awt.Button;
import org.eclipse.swt.widgets.Button;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.StackLayout;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
//import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;



/**
 * S PURVAJ 
 * DBMS PROJECT 
 * 
 *
 */
public class App 
{
	static int pageNum=-1;
    public static void main( String[] args )
    {

        
        Configuration c = new Configuration().configure().addAnnotatedClass(Dealer.class).addAnnotatedClass(Order.class).addAnnotatedClass(Customer.class).addAnnotatedClass(Vehicle.class);
        ServiceRegistry sr = new StandardServiceRegistryBuilder().applySettings(c.getProperties()).build();
        SessionFactory sf = c.buildSessionFactory(sr);        
        Session session = sf.openSession();
        
        Features sys = new Features(session);
        
        Display display = new Display();
        Shell shell = new Shell(display);
        shell.setLayout(new GridLayout(1,false));
        final Composite contentPanel = new Composite(shell, SWT.BORDER);
        contentPanel.setSize(100, 100);
//        contentPanel.setBounds(100,100,500,500);
//        contentPanel.setB
//        final StackLayout layout =  new StackLayout();
       
//        contentPanel.setLayout(layout);
        final CustomerInput cust = new CustomerInput(contentPanel, SWT.NONE, session);
//        shell.setBounds(500,500,3, height);
//        contentPanel.
        
//        final Menu menu = new Menu(contentPanel,SWT.NONE,layout,session);
//        layout.topControl = menu;
//        contentPanel.layout();
//        shell.pack();
        shell.setSize(500,500);
        shell.open();
        while(!shell.isDisposed()) {
        
        	if(!display.readAndDispatch()) {
        		display.sleep();
        	}
        }

        session.close();
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
//        sys.createCustomer("Purvaj","spurvaj@gmail.com");
//        
//        Dealer deal = new Dealer("Dealer2");
//        sys.createDealer(deal);
//        
//        System.out.println("___________________"+sys.getCustomerID("Purvaj","spurvaj@gmail.com"));
//        
//        Order ord = new Order(1,1);
//        sys.placeOrder(1,1);
//        
//        sys.produceVehicle();
//        
//        sys.contactCustomer();
//        
//        sys.deliverCustomer();
//        
//        sys.exitsystem();
        
    }
}
